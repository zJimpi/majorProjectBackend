package com.travel.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.travel.dto.UserDto;
import com.travel.entity.User;

public interface UserService {

    UserDto saveUser(User user);
    // Method to save a new user. It takes a 'User' object and returns a 'UserDto' representing the saved user.

    void deleteUserById(Long userId);
    // Method to delete a user by its unique identifier (userId).

    UserDto updateUser(Long userId, User user);
    // Method to update an existing user with the specified 'userId'. It takes a 'User' object and returns a 'UserDto' representing the updated user.

    List<UserDto> getUserList();
    // Method to retrieve a list of user data, typically as a list of 'UserDto' objects.

	UserDto checkUserCredentials(String value, String password);


	byte[] getUserProfilePicture(long userId);

	void changeUserPassword(long userId, String newPassword);

	User getUserById(long userId);

	void updateUserProfilePicture(long userId, MultipartFile profilePicture);
}
